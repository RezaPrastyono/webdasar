<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/public/style.css">
    <title>Reza Prasetyono</title>
</head>
<body>
    <div class="product-container">
        <h2 class="product-title">Daftar Produk Elektronik</h2>
        <form action="/submit-product" method="POST" class="product-form">
          <div class="form-group">
            <label for="productName">Nama Produk:</label>
            <input type="text" id="productName" name="productName" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="productNumber">Nomor Produk:</label>
            <input type="text" id="productNumber" name="productNumber" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="productPrice">Harga:</label>
            <input type="text" id="productPrice" name="productPrice" class="form-control" required>
          </div>
          <div class="form-group">
            <label for="productQuantity">Jumlah Barang:</label>
            <input type="number" id="productQuantity" name="productQuantity" class="form-control" required>
          </div>
          <button type="submit" class="btn btn-primary">simpan</button>
        </form>
      </div>
</body>
</html><?php /**PATH D:\nita-natalia\resources\views/reza.blade.php ENDPATH**/ ?>